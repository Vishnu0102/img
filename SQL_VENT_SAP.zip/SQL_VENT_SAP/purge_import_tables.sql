truncate table IMPORT_CANAL;
truncate table IMPORT_CODSOC_DOMACT;
truncate table IMPORT_FAMCPT;
truncate table IMPORT_OPEPART;
truncate table IMPORT_OPEPRINC;
truncate table IMPORT_WORDING;
/