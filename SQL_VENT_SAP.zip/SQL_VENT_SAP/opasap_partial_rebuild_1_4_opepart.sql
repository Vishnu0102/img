SELECT 'Debut reconstruction table: T_OPEPART @ ' || TO_CHAR(CURRENT_TIMESTAMP)
  FROM DUAL
/
--
-- MODELE : SAP             --
-- TABLE  : T_OPEPART       --
------------------------------


--SELECT REGEXP_SUBSTR(CATEG_CPT, '[^(]+', 1, 1) AS FONCTION
--  FROM IMPORT_REF_COMP
-- WHERE is_val_cpt_func_based = 1
--/

--SELECT REGEXP_REPLACE(CATEG_CPT, '[^(]+\((.*)\)$', '\1') AS OPERANDE
--  FROM IMPORT_REF_COMP
-- WHERE is_val_cpt_func_based = 1
--/

--SELECT SUBRULE_ID, RULE_LABEL, REGEXP_COUNT(CATEG_CPT, '^\$[^(]+', 1, 'i') AS IS_FONCTION
--  FROM IMPORT_REF_COMP
--/ 

--SELECT REGEXP_COUNT(FPM, '^\$[^(]+', 1, 'i') AS IS_FONCTION
--  FROM IMPORT_GUVGUT_MACAO
--/


--
-- 1st step : close existing rule if any
--

-- #Step 0.1, close existing rule value set from T_R_RULE_VALUE table
DELETE FROM T_R_RULE_VALUE RRV
 WHERE EXISTS ( SELECT 1 
                  FROM IMPORT_OPEPART IMP
                 INNER JOIN T_CODE_PILOTE CPL
                    ON (    IMP.SUBJECT            = CPL.SUBJECT
                        AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                 INNER JOIN T_OPE_PART ope
                    ON (    IMP.RULE_NAME  = ope.RULE_NAME 
                        AND TRIM(IMP.BLOC)       = TRIM(ope.BLOC) )
                 WHERE RRV.RULE_ID       = ope.RULE_ID
                   AND RRV.ISSUE_DT      = ope.ISSUE_DT
                   AND IMP.TYPE_OPERATION  IN ('DEL' , 'UPD')
              )
/

-- #Step 0.2, close existing rule control condition set from T_R_RULE_CTRL_OPRND table
DELETE FROM  T_R_RULE_CTRL_OPRND RRCC
 WHERE EXISTS ( SELECT 1 
                  FROM IMPORT_OPEPART IMP
                 INNER JOIN T_CODE_PILOTE CPL
                    ON (    IMP.SUBJECT            = CPL.SUBJECT
                        AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                 INNER JOIN T_OPE_PART ope
                    ON (    IMP.RULE_NAME  = ope.RULE_NAME 
                        AND TRIM(IMP.BLOC)       = TRIM(ope.BLOC) )
                 WHERE RRCC.RULE_ID       = ope.RULE_ID
                   AND RRCC.ISSUE_DT      = ope.ISSUE_DT
                   AND IMP.TYPE_OPERATION   IN ('DEL' , 'UPD')                                              
              )
/

-- 0st step : Deleting rules if exist
DELETE FROM T_OPE_PART ope
WHERE EXISTS ( SELECT 1 
               FROM IMPORT_OPEPART IMP
                 INNER JOIN T_CODE_PILOTE CPL
                    ON (    IMP.SUBJECT            = CPL.SUBJECT
                        AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                 WHERE ope.RULE_NAME       = IMP.RULE_NAME
                   AND TRIM(ope.BLOC)            = TRIM(IMP.BLOC)
                   AND IMP.TYPE_OPERATION  = 'DEL'
              );          
/  

-- #Step 1.1, close existing rule from T_XXXX rule table
UPDATE T_OPE_PART OPP
   SET ( OPP.LAST_UPDATE, OPP.EXPIRATION_DT) = ( SELECT IMP.LAST_UPDATE, IMP.END_DATE 
                                                   FROM IMPORT_OPEPART IMP
												   INNER JOIN T_CODE_PILOTE CPL
                                                     ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
															AND IMP.SUBJECT            = CPL.SUBJECT
															AND IMP.SUBRULE_ID         = 1
															AND IMP.TYPE_OPERATION  = 'UPD'
															AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                                                  WHERE OPP.RULE_NAME = IMP.RULE_NAME
                                                   -- AND OPP.ISSUE_DT <= IMP.LAST_UPDATE
                                                    AND OPP.EXPIRATION_DT = TO_DATE('2999-12-31', 'YYYY-MM-DD')
                                               )
 WHERE EXISTS ( SELECT 1 
                  FROM IMPORT_OPEPART IMP
				  INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
							AND IMP.SUBRULE_ID         = 1
							AND IMP.TYPE_OPERATION  = 'UPD'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                 WHERE OPP.RULE_NAME = IMP.RULE_NAME
                  -- AND OPP.ISSUE_DT <= IMP.LAST_UPDATE
                   AND OPP.EXPIRATION_DT = TO_DATE('2999-12-31', 'YYYY-MM-DD')
              )
/

-- #Step 1.2, close existing rule control condition set from T_R_RULE_CTRL_COND table
UPDATE T_R_RULE_CTRL_OPRND RRCO
   SET RRCO.EXPIRATION_DT = ( SELECT IMP.LAST_UPDATE
                                FROM IMPORT_OPEPART IMP
								INNER JOIN T_CODE_PILOTE CPL
								 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
										AND IMP.SUBJECT            = CPL.SUBJECT
										AND IMP.SUBRULE_ID         = 1
										AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                               INNER JOIN T_OPE_PART OPP
                                  ON (    IMP.LAST_UPDATE = OPP.LAST_UPDATE 
                                      AND IMP.LAST_UPDATE = OPP.EXPIRATION_DT
                                      AND IMP.RULE_NAME = OPP.RULE_NAME )
                               WHERE RRCO.RULE_ID = OPP.RULE_ID
                                 --AND RRCO.ISSUE_DT <= IMP.LAST_UPDATE
                                 AND RRCO.EXPIRATION_DT = TO_DATE('2999-12-31', 'YYYY-MM-DD') 
                            )
 WHERE EXISTS ( SELECT 1 
                  FROM IMPORT_OPEPART IMP
				  INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
							AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                 INNER JOIN T_OPE_PART OPP
                    ON (    IMP.LAST_UPDATE = OPP.LAST_UPDATE 
                        AND IMP.LAST_UPDATE = OPP.EXPIRATION_DT
                        AND IMP.RULE_NAME = OPP.RULE_NAME )
                 WHERE RRCO.RULE_ID = OPP.RULE_ID
                   --AND RRCO.ISSUE_DT <= IMP.LAST_UPDATE
                   AND RRCO.EXPIRATION_DT = TO_DATE('2999-12-31', 'YYYY-MM-DD')
              )
/

-- #Step 1.3, close existing rule value set from T_R_RULE_VALUE table
UPDATE T_R_RULE_VALUE RRV
   SET RRV.EXPIRATION_DT = ( SELECT IMP.LAST_UPDATE
                               FROM IMPORT_OPEPART IMP
							   INNER JOIN T_CODE_PILOTE CPL
								 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
										AND IMP.SUBJECT            = CPL.SUBJECT
										AND IMP.SUBRULE_ID         = 1
										AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                              INNER JOIN T_OPE_PART OPP
                                 ON (    IMP.LAST_UPDATE = OPP.LAST_UPDATE 
                                     AND IMP.LAST_UPDATE = OPP.EXPIRATION_DT
                                     AND IMP.RULE_NAME = OPP.RULE_NAME )
                              WHERE RRV.RULE_ID = OPP.RULE_ID
                                --AND RRV.ISSUE_DT <= IMP.LAST_UPDATE
                                AND RRV.EXPIRATION_DT = TO_DATE('2999-12-31', 'YYYY-MM-DD') 
                           )
 WHERE EXISTS ( SELECT 1 
                  FROM IMPORT_OPEPART IMP
					INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
							AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
                 INNER JOIN T_OPE_PART OPP
                    ON (    IMP.LAST_UPDATE = OPP.LAST_UPDATE 
                        AND IMP.LAST_UPDATE = OPP.EXPIRATION_DT
                        AND IMP.RULE_NAME = OPP.RULE_NAME )
                 WHERE RRV.RULE_ID = OPP.RULE_ID
                   --AND RRV.ISSUE_DT <= IMP.LAST_UPDATE
                   AND RRV.EXPIRATION_DT = TO_DATE('2999-12-31', 'YYYY-MM-DD')
              )
/

-- Validate change
COMMIT
/

--
-- Construction of table, destination: Integrator
--

INSERT -- As many rules as valid and distinct bloc/condition sets exist in IMPORT_GUVGUT 
  INTO T_OPE_PART (RULE_ID, BLOC, CD_REGROUP, TP_MT_POS, OPE_PRINC, LAST_UPDATE, ISSUE_DT, EXPIRATION_DT, RULE_NAME)
SELECT SEQ_RULE.NEXTVAL, BLOC, CD_REGROUP, TP_MT_POS, OPE_PRINC, LAST_UPDATE, BEGIN_DATE, END_DATE --TO_DATE('2999-12-31', 'YYYY-MM-DD')
, RULE_NAME
  FROM (
         SELECT DISTINCT BLOC, CD_REGROUP, TP_MT_POS, OPE_PRINC, impo.LAST_UPDATE,BEGIN_DATE, END_DATE, RULE_NAME
           FROM IMPORT_OPEPART impo
		   INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo.SUBJECT            = CPL.SUBJECT
							--AND impo.SUBRULE_ID         = 1
							AND impo.TYPE_OPERATION  = 'CRE'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
       ) IMP
/

-- Validate insert results
COMMIT
/

--
-- Construction of table: T_CTRLFPM, destination: Integrator/GUVGUT
--  - Retrieve condtions in a single analysis.
--  - Conditions are made from the association of BLOC / FIELD / OPERATOR / FUNCTION
MERGE
 INTO T_CTRLFPM CTRL
USING (
       -- Controls made on char typed field
       SELECT DISTINCT
              IMP.BLOC,
              FPM.FIELD_ID AS CTRL_FIELD, 
              FPM.FIELD_TYPE AS DATATYPE_ID,
              OPR.OPERATOR_ID,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN '1'
              END AS IS_FCT_BASED,
              IMP.FIELD_NAME||CASE OPR.OPERATOR_ID
                                 WHEN 9  THEN ' SP'
                                 WHEN 10 THEN ' != SPACE(S)'
                                 ELSE CHR(32)||TRIM(OPR.SYMBOL)
              END AS CTRL_NAME,
             CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN NULL
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN IMP.FIELD_NAME
              END AS FCTBASED_CTRLFIELD
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
						--	AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   TRIM(IMP.FIELD_NAME) = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE FPM.FIELD_TYPE < 3
        UNION  
       -- Controls made on numeric typed field  
       SELECT DISTINCT
              IMP.BLOC,
              FPM.FIELD_ID AS CTRL_FIELD, 
              FPM.FIELD_TYPE AS DATATYPE_ID,
              OPR.OPERATOR_ID,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN '1'
              END AS IS_FCT_BASED,
              IMP.FIELD_NAME||CHR(32)||TRIM(OPR.SYMBOL) AS CTRL_NAME,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN NULL
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN IMP.FIELD_NAME
              END AS FCTBASED_CTRLFIELD
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
					--		AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE OPR.OPERATOR_ID < 9
          AND FPM.FIELD_TYPE > 2
      ) MRG
   ON (    TRIM(CTRL.BLOC)  = TRIM(MRG.BLOC)
       AND CTRL.CTRL_FIELD  = MRG.CTRL_FIELD
       AND CTRL.DATATYPE_ID = MRG.DATATYPE_ID
       AND CTRL.OPERATOR_ID = MRG.OPERATOR_ID
       AND CTRL.IS_FCT_BASED = MRG.IS_FCT_BASED
       AND CTRL.CTRL_NAME = MRG.CTRL_NAME)
 WHEN MATCHED 
      THEN UPDATE SET CTRL.REFERENCE_CNT = CTRL.REFERENCE_CNT + 1
 WHEN NOT MATCHED
      THEN INSERT (CONTROL_ID, BLOC, CTRL_FIELD, DATATYPE_ID, OPERATOR_ID, 
                   IS_FCT_BASED, REFERENCE_CNT, CTRL_NAME, FCTBASED_CTRLFIELD)
           VALUES (SEQ_CONTROL.NEXTVAL, MRG.BLOC, MRG.CTRL_FIELD, MRG.DATATYPE_ID, 
                       MRG.OPERATOR_ID, MRG.IS_FCT_BASED, 1, MRG.CTRL_NAME, MRG.FCTBASED_CTRLFIELD)
/

-- Validate merge results
COMMIT
/

--
-- Construction of table: T_CONDITION, destination: Integrator/GUVGUT
--  - Retrieve values in two analysis : single value then values stored in set
--
MERGE
 INTO T_OPERANDE OPE
USING (
       WITH 
         SUB_Q
       AS (
       SELECT DISTINCT RULE_NAME, OPERANDE
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
						--	AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE OPR.OPERATOR_ID > 4
          AND FPM.FIELD_TYPE > 2
          AND REGEXP_COUNT(TRIM(IMP.OPERANDE), '^\$[^(]+', 1, 'i') = 0 /* No function based condition */
          AND TRIM(IMP.OPERANDE) IS NOT NULL
       ),
         SUB_F
       AS (
        SELECT RULE_NAME, TO_CHAR(TO_NUMBER(REGEXP_SUBSTR(OPERANDE, '[0-9]+', 1, RN))) AS CUT_OF
          FROM SUB_Q
         CROSS JOIN ( SELECT ROWNUM RN
                        FROM (SELECT MAX (REGEXP_COUNT(OPERANDE, ',') + 1) MX
                                FROM SUB_Q 
                             )
                     CONNECT BY LEVEL <= MX
                    )
         WHERE REGEXP_SUBSTR(OPERANDE, '[0-9]+', 1, RN) IS NOT NULL
       )
       SELECT DISTINCT
              LISTAGG(CUT_OF, ',') WITHIN GROUP (ORDER BY CUT_OF) AS OPERANDE, 
              '1' AS IS_NUMERIC,
              '1' AS IS_A_SET,
              '0' AS IS_FCT_BASED
         FROM SUB_F
        GROUP BY SUB_F.RULE_NAME
        UNION
       SELECT DISTINCT 
              IMP.OPERANDE,
              '0' AS IS_NUMERIC,
              '0' AS IS_A_SET,
              CASE
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
							--AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE OPR.OPERATOR_ID IN (9, 10)
          AND FPM.FIELD_TYPE < 3
        UNION
       SELECT DISTINCT 
              CASE
                 WHEN FPM.FIELD_TYPE <= 2 THEN IMP.OPERANDE
                 WHEN FPM.FIELD_TYPE >= 3 THEN TO_CHAR(TO_NUMBER(IMP.OPERANDE))
               END AS OPERANDE,
              CASE
                 WHEN FPM.FIELD_TYPE < 3 THEN '0'
                 WHEN FPM.FIELD_TYPE > 2 THEN '1'
               END AS IS_NUMERIC,
              '0' AS IS_A_SET,
              CASE
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
							--AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE OPR.OPERATOR_ID < 5
          AND TRIM(IMP.OPERANDE) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.OPERANDE, '0' AS IS_NUMERIC, '1' AS IS_A_SET, '0' AS IS_FCT_BASED /* A set of value cannot be function based */
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
							--AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE OPR.OPERATOR_ID > 4
          AND OPR.OPERATOR_ID < 9
          AND FPM.FIELD_TYPE < 3
          AND TRIM(IMP.OPERANDE) IS NOT NULL
      ) MRG_CND
   ON (    OPE.LVALUE = MRG_CND.OPERANDE
       AND OPE.IS_NUMERIC = MRG_CND.IS_NUMERIC
       AND OPE.IS_A_SET = MRG_CND.IS_A_SET     
       AND OPE.IS_FCT_BASED = MRG_CND.IS_FCT_BASED )
 WHEN MATCHED 
      THEN UPDATE SET OPE.REFERENCE_CNT = OPE.REFERENCE_CNT + 1
 WHEN NOT MATCHED
      THEN INSERT (OPERANDE_ID, LVALUE, IS_NUMERIC, IS_A_SET, IS_FCT_BASED, REFERENCE_CNT, OPERANDE_NAME)
    VALUES (SEQ_OPERANDE.NEXTVAL, MRG_CND.OPERANDE, MRG_CND.IS_NUMERIC, MRG_CND.IS_A_SET, 
                                   MRG_CND.IS_FCT_BASED, 1, 'OPERANDE_'||LTRIM(TO_CHAR(SEQ_OPERANDE.CURRVAL, '099999')))
                                   
/

-- Validate merge results
COMMIT
/

--
-- Construction of table: T_VALUE, destination: Integrator/REFCOMP
-- - As many values as valid and distinct rules exist in IMPORT_REFCOMP
--
MERGE 
 INTO T_VALUE VAL
USING (
       SELECT DISTINCT
              IMP.OPE_PART AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.OPE_PART ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.OPE_PART ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
						--	AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.OPE_PART) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.ID_FAM AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.ID_FAM ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.ID_FAM ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
						--	AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.ID_FAM) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.INV_SENSMT AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.INV_SENSMT ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.INV_SENSMT ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
						--	AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.INV_SENSMT) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.TOP_UJ AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UJ ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UJ ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
					 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND IMP.SUBJECT            = CPL.SUBJECT
						--	AND IMP.SUBRULE_ID         = 1
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.TOP_UJ) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.MESURE AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.MESURE ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.MESURE ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
				--	AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.MESURE) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.TOP_UV AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UV ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UV ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
 		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
				--	AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.TOP_UV) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.TOP_UT AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UT ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UT ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
				--	AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.TOP_UT) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.TOP_UE AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UE ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.TOP_UE ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
				--	AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.TOP_UE) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.TOP_REP AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.TOP_REP ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.TOP_REP ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					--AND IMP.SUBJECT            = CPL.SUBJECT
					AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.TOP_REP) IS NOT NULL
        UNION
       SELECT DISTINCT
              IMP.TOP_DEST AS DATA_VALUE,
              CASE
                 WHEN REGEXP_COUNT(trim( IMP.TOP_DEST ), '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(trim( IMP.TOP_DEST ), '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
					--AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        WHERE TRIM(IMP.TOP_DEST) IS NOT NULL
	) MRG
   ON (    VAL.DATA_VALUE = MRG.DATA_VALUE
       AND VAL.IS_FCT_BASED = MRG.IS_FCT_BASED)
 WHEN MATCHED 
      THEN UPDATE SET VAL.REFERENCE_CNT = VAL.REFERENCE_CNT + 1
 WHEN NOT MATCHED
      THEN INSERT ( VALUE_ID, DATA_VALUE, REFERENCE_CNT, IS_FCT_BASED )
    VALUES ( SEQ_VALUE.NEXTVAL, MRG.DATA_VALUE, 1, MRG.IS_FCT_BASED )
/

-- Validate merge results
COMMIT
/


INSERT
  INTO T_R_RULE_CTRL_OPRND ( RULE_ID, CONTROL_ID, BLOC, OPERANDE_ID, ISSUE_DT, EXPIRATION_DT)
SELECT OPP.RULE_ID, CTL.CONTROL_ID, OPP.BLOC, OPE.OPERANDE_ID, OPP.ISSUE_DT, OPP.EXPIRATION_DT
FROM (
  WITH
         SUB_Q
       AS (
       -- Tous les couples controles/operandes dont :
       --   le champ contr�l� est de type num�rique
       --   l'op�rateur de condition est IN ou NOT IN 
       --   l'op�rande est un ensemble de valeur � filtrer pour ne conserver que le num�rique
       --   de facto : l'op�rande ne peut pas �tre une fonction
       --              l'op�rande est forc�ment un ensemble
       SELECT DISTINCT 
              IMP.BLOC,
              IMP.CD_REGROUP, IMP.TP_MT_POS, IMP.OPE_PRINC,
              IMP.RULE_NAME,
              IMP.LAST_UPDATE,
              IMP.BEGIN_DATE,
			  IMP.END_DATE,
              FPM.FIELD_ID AS CTRL_FIELD,
              FPM.FIELD_TYPE AS DATATYPE_ID,
              OPR.OPERATOR_ID,
			  OPR.SYMBOL,
			  IMP.FIELD_NAME,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN '1'
              END AS CTL_FCT_BASED,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN NULL
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN IMP.FIELD_NAME
              END AS FCTBASED_CTRLFIELD,
              IMP.OPERANDE, 
              '1' AS CND_IS_NUMERIC,
              '0' AS CND_FCT_BASED,
              '1' AS CND_IS_A_SET
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
					AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE OPR.OPERATOR_ID IN (5, 6)
          AND FPM.FIELD_TYPE > 2
          AND REGEXP_COUNT(TRIM(IMP.OPERANDE), '^\$[^(]+', 1, 'i') = 0 /* No function based condition */
          AND TRIM(IMP.OPERANDE) IS NOT NULL
		  AND IMP.TYPE_OPERATION <> 'DEL'
       ),
         SUB_F
       AS (
       -- Eclatement et filtrage des valeurs pr�c�dentes :
       --   Filtrage : seule les valeurs num�riques sont conserv�es, ex => 01,AB,02 devient 1,2
       --   Eclatement : 'K1','K2','K3','01,AB,02' 
       --      devient : 'K1','K2','K3',1
       --                'K1','K2','K3',2 
       SELECT BLOC, RULE_NAME, CD_REGROUP, TP_MT_POS, OPE_PRINC, LAST_UPDATE, BEGIN_DATE, END_DATE, CTRL_FIELD, DATATYPE_ID, OPERATOR_ID, SYMBOL,
              FIELD_NAME,CTL_FCT_BASED, FCTBASED_CTRLFIELD, CND_IS_NUMERIC, CND_FCT_BASED, CND_IS_A_SET,
              TO_CHAR(TO_NUMBER(REGEXP_SUBSTR(OPERANDE, '[0-9]+', 1, RN))) AS SETV_FILTERED
         FROM SUB_Q
        CROSS JOIN ( SELECT ROWNUM RN
                        FROM (SELECT MAX (REGEXP_COUNT(OPERANDE, ',') + 1) MX
                                FROM SUB_Q 
                             )
                     CONNECT BY LEVEL <= MX
                    )
        WHERE REGEXP_SUBSTR(OPERANDE, '[0-9]+', 1, RN) IS NOT NULL
       )
       -- Regroupement de tous les couples controles/operandes dont :
       --   le champ contr�l� est de type num�rique
       --   l'op�rateur de condition est IN ou NOT IN 
       --   l'op�rande est un ensemble de valeur filtr�e pour ne conserver que le num�rique
       --   de facto : l'op�rande ne peut pas �tre une fonction
       --              l'op�rande est forc�ment un ensemble
       SELECT DISTINCT
              BLOC, RULE_NAME, CD_REGROUP, TP_MT_POS, OPE_PRINC, LAST_UPDATE, BEGIN_DATE, END_DATE, CTRL_FIELD, DATATYPE_ID, OPERATOR_ID, SYMBOL,
              FIELD_NAME, CTL_FCT_BASED, FCTBASED_CTRLFIELD,
              LISTAGG(SETV_FILTERED, ',') WITHIN GROUP (ORDER BY SETV_FILTERED) AS OPERANDE,
              CND_IS_NUMERIC, CND_FCT_BASED, CND_IS_A_SET
         FROM SUB_F
        GROUP BY BLOC, RULE_NAME, CD_REGROUP, TP_MT_POS, OPE_PRINC, LAST_UPDATE,BEGIN_DATE, END_DATE, CTRL_FIELD, DATATYPE_ID, OPERATOR_ID, SYMBOL, FIELD_NAME, CTL_FCT_BASED, FCTBASED_CTRLFIELD,
                  CND_IS_NUMERIC, CND_FCT_BASED, CND_IS_A_SET
        UNION  
       -- Tous les couples controles/operandes dont :
       --   le champ contr�l� est de type num�rique
       --   l'op�rateur de condition n'est pas IN, NOT IN, SPACES ou !SPACES 
       --   de facto : l'op�rande est une valeur unique ET num�rique
       SELECT DISTINCT
              IMP.BLOC, 
              IMP.RULE_NAME,
              IMP.CD_REGROUP, IMP.TP_MT_POS, IMP.OPE_PRINC,
              IMP.LAST_UPDATE,
              IMP.BEGIN_DATE,
			  IMP.END_DATE,
              FPM.FIELD_ID AS CTRL_FIELD,
              FPM.FIELD_TYPE AS DATATYPE_ID,
              OPR.OPERATOR_ID,
			  OPR.SYMBOL,
			  IMP.FIELD_NAME,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN '1'
              END AS CTL_FCT_BASED,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN NULL
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN IMP.FIELD_NAME
              END AS FCTBASED_CTRLFIELD,
              CASE
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') = 0 THEN TO_CHAR(TO_NUMBER(IMP.OPERANDE))
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') > 0 THEN IMP.OPERANDE
               END AS OPERANDE, 
              '1' AS CND_IS_NUMERIC,
              CASE
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED,
			       '0' CND_IS_A_SET
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
					--AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE 
		---modif idir mettre comentaitre pour OPR.OPERATOR_ID NOT IN (5,6)
		---
		 --OPR.OPERATOR_ID NOT IN (5,6)
           OPR.OPERATOR_ID < 9
          AND FPM.FIELD_TYPE > 2
          AND TRIM(IMP.OPERANDE) IS NOT NULL
		  AND IMP.TYPE_OPERATION <> 'DEL'
        UNION
       -- Tous les couples controles/operandes dont :
       --   le champ contr�l� est de type aplhanum�rique
       SELECT DISTINCT
              IMP.BLOC, 
              IMP.RULE_NAME,
              IMP.CD_REGROUP, IMP.TP_MT_POS, IMP.OPE_PRINC,
              IMP.LAST_UPDATE,
              IMP.BEGIN_DATE,
			  IMP.END_DATE,
              FPM.FIELD_ID AS CTRL_FIELD,
              FPM.FIELD_TYPE AS DATATYPE_ID,
              OPR.OPERATOR_ID,
			  OPR.SYMBOL,
			  IMP.FIELD_NAME,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN '1'
              END AS CTL_FCT_BASED,
              CASE
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') = 0 THEN NULL
                 WHEN REGEXP_COUNT(IMP.FIELD_NAME, '^\$[^(]+', 1, 'i') > 0 THEN IMP.FIELD_NAME
              END AS FCTBASED_CTRLFIELD,
              IMP.OPERANDE, 
              '0' AS CND_IS_NUMERIC,
              CASE
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') = 0 THEN '0'
                 WHEN REGEXP_COUNT(IMP.OPERANDE, '^\$[^(]+', 1, 'i') > 0 THEN '1'
               END AS IS_FCT_BASED,
              CASE OPR.OPERATOR_ID
                 WHEN 5 THEN '1'
                 WHEN 6 THEN '1'
                 ELSE '0'
              END AS CND_IS_A_SET
         FROM IMPORT_OPEPART IMP
		 INNER JOIN T_CODE_PILOTE CPL
			 ON (    IMP.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
					AND IMP.SUBJECT            = CPL.SUBJECT
				--	AND IMP.SUBRULE_ID         = 1
					AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
        INNER JOIN T_FPM_DICT FPM
           ON (   IMP.FIELD_NAME = FPM.FIELD_NAME
               OR REGEXP_REPLACE(IMP.FIELD_NAME, '^.*FPM\((.*)\),.*$', '\1', 1) = FPM.FIELD_NAME )
        INNER JOIN T_OPERATOR OPR
           ON ( TRIM(IMP.OP_SYMBOL) = TRIM(OPR.SYMBOL) )
        WHERE FPM.FIELD_TYPE < 3
          AND TRIM(IMP.OPERANDE) IS NOT NULL
		  AND IMP.TYPE_OPERATION <> 'DEL'
       ) PFLT
 INNER JOIN T_OPE_PART OPP
    ON (    TRIM(PFLT.BLOC) = TRIM(OPP.BLOC)
        AND PFLT.CD_REGROUP = OPP.CD_REGROUP
        AND PFLT.TP_MT_POS = OPP.TP_MT_POS
        AND PFLT.OPE_PRINC = OPP.OPE_PRINC
        AND PFLT.RULE_NAME = OPP.RULE_NAME
        --AND PFLT.LAST_UPDATE = OPP.LAST_UPDATE
        --AND PFLT.BEGIN_DATE = OPP.ISSUE_DT 
        --AND OPP.EXPIRATION_DT = PFLT.END_DATE
     )
 INNER JOIN T_CTRLFPM CTL
    ON (    TRIM(PFLT.BLOC) = TRIM(CTL.BLOC)
        AND PFLT.CTRL_FIELD = CTL.CTRL_FIELD
        AND PFLT.DATATYPE_ID = CTL.DATATYPE_ID
        AND PFLT.OPERATOR_ID = CTL.OPERATOR_ID
        AND PFLT.CTL_FCT_BASED = CTL.IS_FCT_BASED
        AND NVL(PFLT.FCTBASED_CTRLFIELD,0) = NVL(CTL.FCTBASED_CTRLFIELD,0) 
		AND CTL.CTRL_NAME = PFLT.FIELD_NAME||CHR(32)||TRIM(PFLT.SYMBOL)	)
 INNER JOIN T_OPERANDE OPE
    ON (    PFLT.OPERANDE = OPE.LVALUE
        AND PFLT.CND_IS_NUMERIC = OPE.IS_NUMERIC
        AND PFLT.CND_FCT_BASED = OPE.IS_FCT_BASED
        AND PFLT.CND_IS_A_SET = OPE.IS_A_SET 
		)
/

-- Validate insert results
COMMIT
/

--
-- Set up data into rule vs value relation table
--
INSERT 
  INTO T_R_RULE_VALUE (RULE_ID , VALUE_ID , VALUE_RANK , ISSUE_DT , EXPIRATION_DT)
SELECT RUL.RULE_ID, VAL.VALUE_ID, IMP.VALUE_RANK, RUL.ISSUE_DT, RUL.EXPIRATION_DT
  FROM T_OPE_PART RUL
 INNER JOIN (
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(OPE_PART) , '@') AS DATA_VALUE,
                      1 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(OPE_PART, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo.LAST_UPDATE
                FROM IMPORT_OPEPART impo
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo.SUBJECT            = CPL.SUBJECT
							AND impo.SUBRULE_ID         = 1
							AND impo.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
               SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(ID_FAM) , '@') AS DATA_VALUE,
                      2 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(ID_FAM, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo2.LAST_UPDATE
                FROM IMPORT_OPEPART impo2
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo2.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo2.SUBJECT            = CPL.SUBJECT
							AND impo2.SUBRULE_ID         = 1
							AND impo2.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(INV_SENSMT) , '@') AS DATA_VALUE,
                      3 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(INV_SENSMT, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo3.LAST_UPDATE
                FROM IMPORT_OPEPART impo3
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo3.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo3.SUBJECT            = CPL.SUBJECT
							AND impo3.SUBRULE_ID         = 1
							AND impo3.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(TOP_UJ) , '@') AS DATA_VALUE,
                      4 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(TOP_UJ, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo4.LAST_UPDATE
                FROM IMPORT_OPEPART impo4
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo4.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo4.SUBJECT            = CPL.SUBJECT
							AND impo4.SUBRULE_ID         = 1
							AND impo4.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(MESURE) , '@') AS DATA_VALUE,
                      5 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(MESURE, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo5.LAST_UPDATE
                FROM IMPORT_OPEPART impo5
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo5.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo5.SUBJECT            = CPL.SUBJECT
							AND impo5.SUBRULE_ID         = 1
							AND impo5.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(TOP_UV) , '@') AS DATA_VALUE,
                      6 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(TOP_UV, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo6.LAST_UPDATE
                FROM IMPORT_OPEPART impo6
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo6.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo6.SUBJECT            = CPL.SUBJECT
							AND impo6.SUBRULE_ID         = 1
							AND impo6.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(TOP_UT) , '@') AS DATA_VALUE,
                      7 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(TOP_UT, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo7.LAST_UPDATE
                FROM IMPORT_OPEPART impo7
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo7.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo7.SUBJECT            = CPL.SUBJECT
							AND impo7.SUBRULE_ID         = 1
							AND impo7.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(TOP_UE) , '@') AS DATA_VALUE,
                      8 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(TOP_UE, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo8.LAST_UPDATE
                FROM IMPORT_OPEPART impo8
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo8.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo8.SUBJECT            = CPL.SUBJECT
							AND impo8.SUBRULE_ID         = 1
							AND impo8.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(TOP_REP) , '@') AS DATA_VALUE,
                      9 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(TOP_REP, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo9.LAST_UPDATE
                FROM IMPORT_OPEPART impo9
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo9.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo9.SUBJECT            = CPL.SUBJECT
							AND impo9.SUBRULE_ID         = 1
							AND impo9.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
               UNION
              SELECT DISTINCT 
                      RULE_NAME,
                      BLOC,
                      CD_REGROUP, TP_MT_POS, OPE_PRINC,
                      NVL(TRIM(TOP_DEST) , '@') AS DATA_VALUE,
                      10 AS VALUE_RANK, 
                      CASE
                         WHEN REGEXP_COUNT(TOP_DEST, '^\$[^(]+', 1, 'i') > 0 THEN '1'
						 ELSE '0'
                      END AS IS_FCT_BASED,
                      impo10.LAST_UPDATE
                FROM IMPORT_OPEPART impo10
				INNER JOIN T_CODE_PILOTE CPL
					 ON (    impo10.QUALITY_CONTROL_ID = CPL.QUALITY_CONTROL_ID
							AND impo10.SUBJECT            = CPL.SUBJECT
							AND impo10.SUBRULE_ID         = 1
							AND impo10.TYPE_OPERATION <> 'DEL'
							AND CPL.ENVIRONMENT        = '&&TargetEnvironment' )
            ) IMP
    ON (    TRIM(RUL.BLOC) = TRIM(IMP.BLOC)
        AND RUL.CD_REGROUP = IMP.CD_REGROUP
        AND RUL.TP_MT_POS = IMP.TP_MT_POS
        AND RUL.OPE_PRINC = IMP.OPE_PRINC
        AND RUL.RULE_NAME = IMP.RULE_NAME
        AND RUL.LAST_UPDATE  = IMP.LAST_UPDATE
       -- AND RUL.EXPIRATION_DT = TO_DATE('2999-12-31', 'YYYY-MM-DD') 
		)
 INNER JOIN T_VALUE VAL
    ON (    IMP.DATA_VALUE = VAL.DATA_VALUE
        AND IMP.IS_FCT_BASED = VAL.IS_FCT_BASED)
/

-- Validate insert results
COMMIT
/


--
-- Mise en oeuvre d'un confort de recherche
--
--TRUNCATE TABLE GTMP_SIGNATURE
--/

--INSERT 
--  INTO GTMP_SIGNATURE(RULE_ID, EXPIRATION_DT, CTRL_HASH, COND_HASH)
--SELECT RULE_ID, EXPIRATION_DT, ORA_HASH(CTRL_LIST), ORA_HASH(COND_LIST) 
--  FROM (
--        SELECT RUL.RULE_ID, RUL.EXPIRATION_DT,
--               LISTAGG(RUL.CONTROL_ID, ',') WITHIN GROUP (ORDER BY RUL.CONTROL_ID) AS CTRL_LIST, 
--               LISTAGG(RUL.OPERANDE_ID, ',') WITHIN GROUP (ORDER BY RUL.OPERANDE_ID) AS COND_LIST 
--          FROM T_R_RULE_CTRL_OPRND RUL
--         INNER JOIN T_OPE_PRINC FLT
--            ON (    RUL.RULE_ID = FLT.RULE_ID 
--                AND RUL.EXPIRATION_DT = FLT.EXPIRATION_DT)
--         GROUP BY RUL.RULE_ID, RUL.EXPIRATION_DT
--     ) HASHBUCKET
--/

--UPDATE T_OPE_PRINC FLT
--   SET (FLT.CTRL_HASH, FLT.COND_HASH) = (SELECT SGN.CTRL_HASH, SGN.COND_HASH
--                                           FROM GTMP_SIGNATURE SGN
--                                          WHERE FLT.RULE_ID = SGN.RULE_ID
--                                            AND FLT.EXPIRATION_DT = SGN.EXPIRATION_DT)
--/

--COMMIT
--/


SELECT 'Fin reconstruction table: T_OPEPART @ ' || TO_CHAR(CURRENT_TIMESTAMP)
  FROM DUAL
/
