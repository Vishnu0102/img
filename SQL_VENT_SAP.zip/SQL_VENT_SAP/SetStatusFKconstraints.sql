SET SERVEROUTPUT ON;
SET FEEDBACK OFF;
SET VERSION OFF;
SET TERM ON;
SET HEADING OFF;
SET ECHO OFF;
DECLARE
	alterTableQuery varchar2(500);
	updateType varchar2(10);
BEGIN
	updateType := '&1';
	dbms_output.put_line('Setting foreign key constraints to ' || updateType);

	IF (UPPER(updateType) not in ('DISABLE' , 'ENABLE')) then
		dbms_output.put_line('Expected parameter''s value are : DISABLE, ENABLE');
	ELSE
    for constraints_infos in ( SELECT distinct ucc1.TABLE_NAME AS TABLE_NAME, uc.constraint_name AS CSTNAME FROM user_constraints uc , user_cons_columns ucc1 WHERE uc.constraint_name = ucc1.constraint_name        AND      uc.constraint_type in ('R') ) LOOP
        alterTableQuery := 'ALTER TABLE ' || constraints_infos.TABLE_NAME ||' ' || updateType || ' CONSTRAINT ' || constraints_infos.CSTNAME;
        --dbms_output.put_line('Set constraint [' || constraints_infos.CSTNAME || '] to ' || updateType);
        execute immediate alterTableQuery;
    end loop;
  END IF;
  dbms_output.put_line('END');
END;
/
SET FEEDBACK ON;