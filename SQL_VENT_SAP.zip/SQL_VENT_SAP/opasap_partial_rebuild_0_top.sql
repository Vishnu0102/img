SELECT 'SAP model: partial build - statistic gathering @ ' || TO_CHAR(CURRENT_TIMESTAMP)
  FROM DUAL
/

--------------------------------------------------------
--  DDL for purging previous signature table
--------------------------------------------------------
TRUNCATE TABLE T_PREV_SIGNATURE DROP STORAGE
/

--------------------------------------------------------
--  DDL for inserting data into T_PREV_SIGNATURE
--------------------------------------------------------
INSERT /* +APPEND */ 
  INTO T_PREV_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_CANAL' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , 0 AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_CANAL DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_CANAL DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_CANAL DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

INSERT /* +APPEND */ 
  INTO T_PREV_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_CODSOC_DOMACT' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , 0 AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_CODSOC_DOMACT DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_CODSOC_DOMACT DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_CODSOC_DOMACT DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

INSERT /* +APPEND */ 
  INTO T_PREV_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_OPE_PRINC' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.AC_GLOB) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_OPE_PRINC DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_OPE_PRINC DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_OPE_PRINC DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

INSERT /* +APPEND */ 
  INTO T_PREV_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_OPE_PART' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.CD_REGROUP||','||DAT.TP_MT_POS||','||DAT.OPE_PRINC) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_OPE_PART DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_OPE_PART DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_OPE_PART DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

INSERT /* +APPEND */ 
  INTO T_PREV_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_FAM_CPT' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.ID_FAM) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_FAM_CPT DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_FAM_CPT DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_FAM_CPT DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/


INSERT /* +APPEND */ 
  INTO T_PREV_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_WORDING' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.ACT_GLOB) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_WORDING DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_WORDING DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_WORDING DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/


SELECT 'SAP model: partial build - statistics collected @ ' || TO_CHAR(CURRENT_TIMESTAMP)
  FROM DUAL
/
