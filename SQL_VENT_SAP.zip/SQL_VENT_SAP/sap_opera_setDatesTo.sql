update import_opeprinc set begin_date = TO_DATE('&&1', 'DD/MM/YYYY'), end_date = TO_DATE('&&2', 'DD/MM/YYYY')
/
COMMIT
/
update import_opepart set begin_date = TO_DATE('&&1', 'DD/MM/YYYY'), end_date = TO_DATE('&&2', 'DD/MM/YYYY')
/
COMMIT
/
update import_famcpt set begin_date = TO_DATE('&&1', 'DD/MM/YYYY'), end_date = TO_DATE('&&2', 'DD/MM/YYYY')
/
COMMIT
/
update import_canal set begin_date = TO_DATE('&&1', 'DD/MM/YYYY'), end_date = TO_DATE('&&2', 'DD/MM/YYYY')
/
COMMIT
/
update import_codsoc_domact set begin_date = TO_DATE('&&1', 'DD/MM/YYYY'), end_date = TO_DATE('&&2', 'DD/MM/YYYY')
/
COMMIT
/