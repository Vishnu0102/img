SELECT 'SAP model: partial build starting @ ' || TO_CHAR(CURRENT_TIMESTAMP)
  FROM DUAL
/


--------------------------------------------------------
--  DDL for setting the target environment
--------------------------------------------------------
ACCEPT TGT_ENV PROMPT 'Enter target environment : '
/

-- 
-- Not useful anymore
-- Because of of the requirement to be able to update by lot
-- the date force procedure is not executed anymore
-- @sap_opera_setDatesTo.sql '01/01/2013' '31/12/2999'
-- /
--

/* Quelques corrections */
UPDATE IMPORT_CODSOC_DOMACT 
   SET FIELD_NAME = TRIM(FIELD_NAME)
/

COMMIT
/

--UPDATE IMPORT_FAMCPT
--   SET OPERANDE = SUBSTR('00' || OPERANDE , -2 )
--  where OPERANDE != 'COND_0'
--/

--COMMIT
--/

UPDATE IMPORT_CODSOC_DOMACT 
   SET FIELD_NAME = 'CD_UJ_SCG'
 WHERE FIELD_NAME = 'UJ'
/

COMMIT
/

@opasap_partial_rebuild_0_top
/
@opasap_partial_rebuild_1_1_canal &&TGT_ENV
/
@opasap_partial_rebuild_1_2_codsoc_domact &&TGT_ENV
/
@opasap_partial_rebuild_1_3_famcpt &&TGT_ENV
/

@opasap_partial_rebuild_1_4_opepart &&TGT_ENV
/

@opasap_partial_rebuild_1_5_opeprinc &&TGT_ENV
/
@opasap_partial_rebuild_1_6_wording &&TGT_ENV
/

-- Controle de coh�rence sur les parenth�ses
with 
table_label as (select distinct trrv.value_id value_id, 
  case 
    when c.rule_id is not null then 'Canal '
    when cd.rule_id is not null then 'CodSoc '
    when f.rule_id is not null then 'FamCpt '
    when opart.rule_id is not null then 'OpePart '
    when oprinc.rule_id is not null then 'OpePrinc '

  end label , 
 c.bloc || cd.bloc ||f.bloc || opart.bloc || oprinc.bloc as table_key
from t_value v
inner join t_r_rule_value trrv on (trrv.value_id = v.value_id)
left outer join t_canal c on (c.rule_id = trrv.rule_id)
left outer join t_codsoc_domact cd on (cd.rule_id = trrv.rule_id)
left outer join t_fam_cpt f on (f.rule_id = trrv.rule_id)
left outer join t_ope_part opart on (opart.rule_id = trrv.rule_id)
left outer join t_ope_princ oprinc on (oprinc.rule_id = trrv.rule_id)

where c.rule_id || cd.rule_id || f.rule_id ||opart.rule_id || oprinc.rule_id is not null
),
grouped_label as (
select value_id , label , listagg(table_key , ',') within group (order by table_key) as Table_Key
from table_label
group by value_id , label
),
counting as (
select data_value,value_id,  regexp_count(data_value , '\(') as opened , regexp_count(data_value , '\)') as closed,
regexp_count(data_value , '\$')  as dollar
from t_value where regexp_count(data_value , '\$') > 0
),
abs_fpm_field as (
select distinct trim(replace(regexp_substr ( data_value , '\$FPM\([^)]*' ) , '$FPM(' , '')) as field from t_value
where  regexp_like ( data_value , '.*\$FPM([^)]).*' )
)
select to_char(counting.value_id) || ' ; ' || 
table_label.label || ' ; ' ||
case 
  when dollar <> closed then 'Missing closing parenthesis' 
  when dollar <> opened then 'Missing opening parenthesis' 
else '' end || ' ; ' ||
data_value || ' ; ' ||
grouped_label.table_key 
from counting
inner join table_label on (table_label.value_id = counting.value_id)
inner join grouped_label on (grouped_label.value_id = counting.value_id)
where dollar <> closed or dollar <> opened
UNION
select to_char(t_value.value_id) || ' ; ' ||
table_label.label || ' ; ' ||
'Unknown FPM field [' || abs_fpm_field.field || ']' || ' ; ' ||
t_value.data_value || ' ; ' ||
grouped_label.table_key
from abs_fpm_field  
left outer join  t_fpm_dict fpm  on (fpm.field_name = abs_fpm_field.field)
inner join t_value on (regexp_like(data_value , '[^\$]*\$FPM\(' || abs_fpm_field.field || '\).*') )
inner join table_label on (table_label.value_id = t_value.value_id)
inner join grouped_label on (grouped_label.value_id = t_value.value_id)
where fpm.field_id is null
;

select 'ATTENTION !!! Des champs FPM sont utilis�s dans les tables d''import mais ne sont pas d�clar� au dico. Consulter la vue V_Missing_FPM_Fields'
from dual where (select count(table_name) from v_missing_fpm_fields) > 1;
/*
 * Commande pour renommer en masse dans cygwin : 
 * for file in *.ldr; do $(echo mv $file ${file//_DATA_TABLE.ldr/.CSV} ); done
 * for file in *.ctl; do $(echo mv $file ${file//_DATA_TABLE.ctl/.CTL} ); done
 * sed -i /^INFILE/d *.CTL ; sed -i /^CONTINUEIF/d *.CTL ; sed -i 's/"[A-Z]*"\.\("[A-Z_0-9]*"\)/\1/g' *.CTL ; sed -i '2 a TRUNCATE' *.CTL
 * 
 * Sur une ligne :
 * for file in *.ldr; do $(echo mv $file ${file//_DATA_TABLE.ldr/.CSV} ); done; for file in *.ctl; do $(echo mv $file ${file//_DATA_TABLE.ctl/.CTL} ); done ; sed -i /^INFILE/d *.CTL ; sed -i /^CONTINUEIF/d *.CTL ; sed -i 's/"[A-Z]*"\.\("[A-Z_0-9]*"\)/\1/g' *.CTL ; sed -i '2 a TRUNCATE' *.CTL
 */
 

--------------------------------------------------------
--  DDL for purging previous signature table
--------------------------------------------------------
TRUNCATE TABLE T_CURR_SIGNATURE DROP STORAGE
/

--------------------------------------------------------
--  DDL for inserting data into T_CURR_SIGNATURE
--------------------------------------------------------
INSERT /* +APPEND */ 
  INTO T_CURR_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_CANAL' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , 0 AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_CANAL DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_CANAL DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_CANAL DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

--------------------------------------------------------
--  DDL for inserting data into T_CURR_SIGNATURE
--------------------------------------------------------
INSERT /* +APPEND */ 
  INTO T_CURR_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_CODSOC_DOMACT' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , 0 AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_CODSOC_DOMACT DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_CODSOC_DOMACT DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_CODSOC_DOMACT DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

INSERT /* +APPEND */ 
  INTO T_CURR_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_OPE_PRINC' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.AC_GLOB) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_OPE_PRINC DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_OPE_PRINC DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_OPE_PRINC DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

INSERT /* +APPEND */ 
  INTO T_CURR_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH ) --HBO tag fin
SELECT 'T_OPE_PART' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.CD_REGROUP||','||DAT.TP_MT_POS||','||DAT.OPE_PRINC) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_OPE_PART DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_OPE_PART DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_OPE_PART DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/

INSERT /* +APPEND */ 
  INTO T_CURR_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_FAM_CPT' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.ID_FAM) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_FAM_CPT DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_FAM_CPT DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_FAM_CPT DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/


INSERT /* +APPEND */ 
  INTO T_CURR_SIGNATURE( TABLE_NAME, RULE_NAME, BLOC, RULE_KEY, EXPIRATION_DT, CTRL_HASH, VAL_HASH )
SELECT 'T_WORDING' AS TABLE_NAME
     , DAT.RULE_NAME
     , DAT.BLOC
     , ORA_HASH(DAT.ACT_GLOB) AS RULE_KEY
     , DAT.EXPIRATION_DT
     , ORA_HASH( SUB_C.CTRL_LIST ) AS CTRL_HASH
     , ORA_HASH( SUB_V.VAL_LIST )  AS VAL_HASH
  FROM T_WORDING DAT
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(TRIM(CTL.CTRL_NAME)||' '||TRIM(OPR.LVALUE), ' AND ') WITHIN GROUP (ORDER BY TRIM(CTL.CTRL_NAME)) AS CTRL_LIST
                FROM T_WORDING DAT
               INNER JOIN T_R_RULE_CTRL_OPRND RCO
                  ON (    DAT.RULE_ID = RCO.RULE_ID  
                      AND DAT.EXPIRATION_DT = RCO.EXPIRATION_DT )
               INNER JOIN T_CTRLFPM CTL
                  ON (    RCO.CONTROL_ID = CTL.CONTROL_ID
                      AND DAT.BLOC = CTL.BLOC)
               INNER JOIN T_OPERANDE OPR
                  ON ( RCO.OPERANDE_ID = OPR.OPERANDE_ID )
               WHERE DAT.ISSUE_DT = RCO.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_C
    ON (     DAT.RULE_ID = SUB_C.RULE_ID  
         AND DAT.BLOC = SUB_C.BLOC
         AND DAT.EXPIRATION_DT = SUB_C.EXPIRATION_DT )
 INNER JOIN (
              SELECT DAT.RULE_ID
                   , DAT.BLOC
                   , DAT.EXPIRATION_DT
                   , LISTAGG(VAL.DATA_VALUE, ',') WITHIN GROUP (ORDER BY RRV.VALUE_RANK) AS VAL_LIST
                FROM T_WORDING DAT
               INNER JOIN T_R_RULE_VALUE RRV
                  ON (    DAT.RULE_ID = RRV.RULE_ID  
                      AND DAT.EXPIRATION_DT = RRV.EXPIRATION_DT )
               INNER JOIN T_VALUE VAL
                  ON ( RRV.VALUE_ID = VAL.VALUE_ID )
               WHERE DAT.ISSUE_DT = RRV.ISSUE_DT
               GROUP BY DAT.RULE_ID, DAT.BLOC, DAT.EXPIRATION_DT
            ) SUB_V
    ON (    DAT.RULE_ID = SUB_V.RULE_ID  
        AND DAT.BLOC = SUB_V.BLOC
        AND DAT.EXPIRATION_DT = SUB_V.EXPIRATION_DT )
/

COMMIT
/


SELECT 'Fin reconstruction modele : SAP @ ' || TO_CHAR(CURRENT_TIMESTAMP)
  FROM DUAL
/
